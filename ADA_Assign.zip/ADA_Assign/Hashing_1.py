#!/usr/bin/env python
# coding: utf-8

# In[73]:


#**********************Go to the end of code to verify add,delete,search operations*******************************************

#This  code is for Hashing with saperate chaining using AVL Tree
class Node:
    def __init__(self,val,data):
        self.val=val
        self.left=None
        self.right=None
        self.Height=0
        self.balf=0
        self.data=data

class AVLTree:
    def __init__(self,root):
        self.rootNode=None
        
        
    def insert(self,key,data):
        if self.rootNode==None:
            self.rootNode=Node(key,data)
            return self.rootNode
        N=Node(key,data)
        if self.search(key)==True:
            print('Key already present ')
            return self.rootNode
        else:
            
            
            def dfs1(root,N):
                if root.val>N.val and root.left is None:
                    root.left=N
#                     print('key inserted but tree not balanced at :',root.val)
                    return 
                elif root.val<N.val and root.right is None:
                    root.right=N
#                     print(' Key inserted but tree not balanced:',root.val)
                    
                elif root.val>N.val:
                    dfs1(root.left,N)
                elif root.val<N.val:
                    dfs1(root.right,N)
            dfs1(self.rootNode,N)
            def dfs11(root):
                if root is not None:
                    root.Height=0
                    dfs11(root.left)
                    dfs11(root.right)
            dfs11(self.rootNode)
            
            
#             print('tree after insertion but not balanced:',self.preOrder(self.rootNode))
            self.putHeights(self.rootNode)
#             print(' heights of nodes after insertion but not balanced:',self.preOrder(self.rootNode))
            self.putBalf(self.rootNode)
            stack=[]
            parent=None
            z=self.findImb(self.rootNode,stack,parent)
#             print('z',z)
            if len(z)==0:
                print('Tree is balanced')
            else:
                z=z.pop()
                
                if z[1]==None:
                    p=self.balanceThisNode(z[0])
                    self.rootNode=p
                else:
#                     print('tree is not balanced at',z[0].val,'parent:',z[1].val)
                    if z[1].left is not None and z[1].left.val==z[0].val:
#                         print('left side',z[1].left.val,z[0].val)
                        
                        p=self.balanceThisNode(z[0])
                        z[1].left=p
                    elif z[1].right is not None and z[1].right.val==z[0].val :
#                         print('right side',z[1].right.val,z[0].val)
                        
                        p=self.balanceThisNode(z[0])
                        print(p.val)
                        z[1].right=p
                        

                
            print('updated root',self.rootNode.val)
            return self.rootNode
                    
                    
                    
                    
                
            
        
            
            
           
        
    def delete(self,key):
        sr=self.search(key)
        if sr!=False:
            root=sr
            if root.left==None and root.right ==None:
                root.val=None
                print('key deleted')
            elif root.right is not None:
                
                def dfs2(root,parent):
                    if root.left is None:
                        return (root,parent)
                    return dfs2(root.left,root)
                x=dfs2(root.right,root)
                print('x',x[0].val,x[1].val)
                
                if x[1].left is not None and x[1].left.val==x[0].val :
                    
                        
                    x[1].left=None
                elif x[1].right is not None and x[1].right.val==x[0].val:
                  
#                     print('on right')
                    x[1].right=None
                root.val=x[0].val
                
                print('key deleted')
                
                    
                
            elif root.left is not None:
                def dfs3(root,parent):
                    if root.right is None:
                        return (root,parent)
                    return dfs3(root.right,root)
                x=dfs3(root.left,root)
                
                print('x',x[0].val,x[1].val)
                
                if x[1].left is not None and x[1].left.val==x[0].val :
                    
                        
                    x[1].left=None
                elif x[1].right is not None and x[1].right.val==x[0].val:
                  
#                     print('on right')
                    x[1].right=None
                root.val=x[0].val
                
#                 root.val=x
#                 x.val=None
                print('key deleted')
            x=self.balanceAfterInsertDelete()
            return x
            
                
            
            
        else:
            
            print('Error: Key not present for deletion ')
            return
        
        
    def balanceAfterInsertDelete(self):
        def dfs11(root):
            if root is not None:
                root.Height=0
                dfs11(root.left)
                dfs11(root.right)
        dfs11(self.rootNode)
            
            
#             print('tree after insertion but not balanced:',self.preOrder(self.rootNode))
        self.putHeights(self.rootNode)
#         print(' heights of nodes after insertion but not balanced:',self.preOrder(self.rootNode))
        self.putBalf(self.rootNode)
        stack=[]
        parent=None
        z=self.findImb(self.rootNode,stack,parent)
#         print('z',z)
        if len(z)==0:
            print('Tree is balanced')
        else:
            z=z.pop()
                
            if z[1]==None:
                p=self.balanceThisNode(z[0])
                self.rootNode=p
            else:
#                 print('tree is not balanced at',z[0].val,'parent:',z[1].val)
                if z[1].left is not None and z[1].left.val==z[0].val:
#                     print('left side',z[1].left.val,z[0].val)
                        
                    p=self.balanceThisNode(z[0])
                    z[1].left=p
                elif z[1].right is not None and z[1].right.val==z[0].val :
#                     print('right side',z[1].right.val,z[0].val)
                        
                    p=self.balanceThisNode(z[0])
#                     print(p.val)
                    z[1].right=p
                        

                
#         print('updated root',self.rootNode.val)
        return self.rootNode
                    
        
        
    def search(self,key):
        x=self.dfs(self.rootNode,key)
        if x==False:
#             print('Key not Found')
            return False
        else:
#             print('Key Found and value at key is: ',x.val)
            return x
        
    def dfs(self,root,key):
        if root is None or root.val is None:
            return False
        if root.val==key:
            return root
        if key is None:
            return False
        else:
            
            if root.val<key:
                return self.dfs(root.right,key)
            else:
                return self.dfs(root.left,key)
    def putHeights(self,root):
        if root is None:
            return 0
        if root.left is None and root.right is None:
            root.Height=1
#             print(root.val,root.Height)
            return root.Height
        elif root.left is not None and root.right is not None:
            x=self.putHeights(root.left)
            y=self.putHeights(root.right)
#             print('left:',x)
#             print('right:',y)
            root.Height= 1+max(x,y)
            return root.Height
        elif root.left is not None:
            root.Height= 1+self.putHeights(root.left)
#             print(root.val,root.Height)
            return root.Height
        elif root.right is not None:
            root.Height=1+self.putHeights(root.right)
            return root.Height
#         else:
#             root.Height=1
#             return root.Height
#         if root.left is None and root.right is None:
#             root.balf=0 
#         elif root.left is None:
#             root.balf=root.right.Height
#         elif root.right is None:
#             root.balf=root.left.Height
#         elif root.left is not None and root.right is not None:
#             root.balf=root.left.Height-root.right.Height
            
            
            
            
   
    def putBalf(self,root):
        if root.left is None:
            lf=0
        elif root.left is not None:
            lf=root.left.Height
        if root.right is None:
            rf=0
        elif root.right is not None:
            rf=root.right.Height

        root.balf=lf-rf
        if root.left is not None:
            self.putBalf(root.left)
        if root.right is not None:
            self.putBalf(root.right)
#         print(root.val,root.balf)
    
    def findImb(self,root,stack,parent):
        if root.left is None and root.right is None:
            return stack

        if root.balf==2 or root.balf==-2:
            stack.append((root,parent))
#             if root.left is None:
#                 lf=0
#             elif root.left is not None:
#                 lf=root.left.balf
#             if root.right is None:
#                 rf=0
#             elif root.right is not None:
#                 rf=root.right.balf
#             if rf !=2 and rf !=-2 and lf !=2 and lf!=-2:
#                 return [stack.pop(),parent]
#             elif rf ==2 or rf ==-2:
#                 return self.findImb(root.right,stack,root)
#             elif lf ==2 or lf==-2:
#                 return self.findImb(root.left,stack,root)

#         elif root.balf!=2 and root.balf !=-2:
#             x=None
#             y=None
        if root.left is not None:
            self.findImb(root.left,stack,root)

        if root.right is not None:     
            self.findImb(root.right,stack,root)
        return stack
#             if x!=None:
#                 return x
#             elif y!=None:
#                 return y
#             else:
#                 return None

        
        
    def balanceThisNode(self,root):
        if root.balf==2:
            #left
            if root.left.balf==1:
                newnode=root.left
                root.left=root.left.right
                newnode.right=root
                return newnode
            ##LEft right
            elif root.left.balf==-1:
                newnode=root.left.right
                root.left.right=root.left.right.left
                newnode.left=root.left
                root.left=newnode
                root.left.balf=1
                
                return self.balanceThisNode(root)
        elif root.balf==-2:
            if root.right.balf==-1:
                newnode=root.right
                root.right=root.right.left
                newnode.left=root
                return newnode
            elif root.right.balf==1:
                newnode=root.right.left
                root.right.left=newnode.right
                newnode.right=root.right
                root.right=newnode
                root.right.balf=-1
                return self.balanceThisNode(root)
    
                
            
    def preOrder(self, root):
        
  
        if not root: 
            return
  
        print(('v:',root.val), end="") 
        self.preOrder(root.left) 
        self.preOrder(root.right) 
        
            
        
            
                
                
# class NodeForChaining:
#     def __init__(self,val):
#         self.val=val
#         self.next=None

class Chaining:
    def __init__(self):
        self.HashTable=[None for i in range(10)]
        print('Object for Chaining with AVL tree is created')
        for i in range(len(self.HashTable)):
            self.HashTable[i]=AVLTree(None)
            
            
    def insert(self,key,data):
        #Hash function 
        key=self.Polynomialaccu(str(key))
        index=key%10
        tree=self.HashTable[index]
        x=tree.insert(key,data)
#         self.HashTable[index].next=x
        print('Pre order traversal of tree at index:',index,'is: ')
        tree.preOrder(x)
    def Polynomialaccu(self,key):
        from sys import getsizeof
    
        x=41
        k=0
    
        for j in range(len(key)):
            k=k+(x**j)*ord(key[j])
        st=bin(k)
        lent=len(st)
        lent=lent/32
#         print(lent)
        f='0'
        p=0
        if lent>1:
            while lent>1:
                f=bin(int(f,2) + int(st[32*p:32*(p+1)],2))
                p=p+1
                lent=lent-1
#             st=bin(k)
#             st2=st[32:]
#             st1=st[:31]
#             f=int(st1,2)+int(st2,2)
            return int(f,2)
        else:
            return k
            
            
            
    def search(self,key):
        val=self.Polynomialaccu(str(key))
        index=val%10
        tree=self.HashTable[index]
        s=tree.search(val)
        if s==False:
            print('Key not Found')
            return False
        else:
            print('Key found and value at key =',key,'is',s.data)
        
        
        
    def delete(self,key):
        
        val=self.Polynomialaccu(str(key))
        index=val%10
        tree=self.HashTable[index]
        s=tree.search(val)
        p=tree.delete(val)
#         self.HashTable[index].next=p
#         if s==False:
#             print('Key Error,Key not found for deletion')
#         else:
            
#             print('key deleted succesfully')
        
    def ValueAtKey(self,key):
        val=self.Polynomialaccu(str(key))
        index=val%10
        tree=self.HashTable[index]
        s=tree.search(val)
        if s==False:
            print('Key Error,Key not found cant return value')
        else:
            print('Value at key =',key,'is',s.data)
        
            
        
            
        
        
                    
                
        
            
    
        
        
    
        
        


# In[74]:


#Open Addressing
#This code is for Hashing with  Linear Probing
import sympy
class LinearProb:
    
    from sys import getsizeof
    def __init__(self):
        self.keys=[]
        self.lenHashTable=0
        self.helping=[]
        self.HashTable=[]
        print('object for Hashing with linear probing created')

        
    def HashTableSize(self,keys):
        
        k=len(keys)
        while (1):
            
            if sympy.isprime(k):
                return k
            else:
                
                k=k+1
    ##Compute key to int and use hash Function x%17
    def hashFunction(self,key):
        x=41
        k=0
#         print('key',key)
        for j in range(len(key)):
            k=k+(x**j)*ord(key[j])
        st=bin(k)
        lent=len(st)
        lent=lent/32

        f='0'
        p=0
        if lent>1:
            while lent>1:
                f=bin(int(f,2) + int(st[32*p:32*(p+1)],2))
                p=p+1
                lent=lent-1

            return int(f,2)%17
        else:
            return k%17
        
       
    #creating new HashTable if number of keys exceeds length of Hash Table
    def create(self,keys):
        l=self.lenHashTable
#         print('l: in create',l)
        for key in self.keys:
            x=self.hashFunction(key[0])
            i=0
            while self.HashTable[(x+i)%l][0]!=key[0]:
                if self.HashTable[(x+i)%l]==[-1,-1] and self.helping[(x+i)%l]!=1:
                    self.HashTable[(x+i)%l]=[key[0],key[1]]
                    break
                else:
                    i=i+1
        return self.HashTable,self.helping
    #Add new key
    def Add(self,key,data):
        b=self.search(key)
#         print(b)
        if b is False:
            print(' so lets add this key')
            x=self.hashFunction(key)
            i=0
            flag=0
            l=self.lenHashTable
            while i<=l and l!=0:
                if self.HashTable[(x+i)%l]==[-1,-1]:
                    self.HashTable[(x+i)%l]=[key,data]
                    self.keys.append([key,data])
                    self.helping[(x+i)%l]=0
                    print('Key added and this is updated Hash Table: ',self.HashTable)
                    flag=1
                    break
                else:
                    i=i+1
            if flag==0:
                k=self.lenHashTable+1
                while(1):
                    if sympy.isprime(k):
                        self.lenHashTable=k
                        break
                    else:
                        k=k+1
#                 print('prev Keys:',self.keys)
                self.keys.append([key,data])
                self.helping=[0]*self.lenHashTable
                self.HashTable=[[-1,-1]]*self.lenHashTable
                self.create(self.keys)
                print('Key added and this is updated Hash Table: ',self.HashTable)
                
    #delete a key in Hash Table if it exist
    def delete(self,key):
        l=self.lenHashTable
        x=self.hashFunction(key)
        i=0
        while(1): # self.HashTable[(x+i)%l]!=key:
            
            
            
            if self.HashTable[(x+i)%l][0]==key:
                self.HashTable[(x+i)%l]=[-1,-1]
                self.helping[(x+i)%l]=1
                return self.HashTable
            elif i==l:#self.HashTable[(x+i)%l]==-1 and self.helping[(x+i)%l]!=1:
#                     self.HashTable[(x+i)%l]=key
                print('Error Key not found')
                break
#             print(self.HashTable)
            i=i+1
    def search(self,key):
        l=self.lenHashTable
        
        if l==0:
            return False
        x=self.hashFunction(key)
        i=0
        
#         if self.HashTable[(x+i)%l]==key:
        while(1): # self.HashTable[(x+i)%l]!=key:
            
    
            
            
            if self.HashTable[(x+i)%l][0]==key:
#                 
                print('Key is present at index:',(x+i)%l)
                self.helping[(x+i)%l]=1
                return (x+i)%l
            elif i==l:#self.HashTable[(x+i)%l]==-1 and self.helping[(x+i)%l]!=1:
#                     self.HashTable[(x+i)%l]=key
                print('Error Key not found',end='')
                return False
#             print(self.HashTable)
            i=i+1
    def ValueAtKey(self,key):
        x=self.search(key)
        if x==False:
            pass
        else:
            print('value at key=',key,'is',self.HashTable[x][1])
        
        


# In[75]:


#Open Addressing
# This code is for  Double Hashing
import sympy
class DoubleHash:
    def __init__(self):
        self.keys=[]
        self.lenHashTable=0
        self.helping=[]
        self.HashTable=[]
        print('object for double Hashing is created')
        
    def HashTableSize(self,keys):
        
        k=len(keys)
        while (1):
            
            if sympy.isprime(k) is True:
                return k
            else:
                
                k=k+1
        
    def Add(self,key,data):
        b=self.search(key)
        if b is False:
            print('so lets add this key')
            x=self.hashFunction1(key)
            y=self.hashFunction2(key)
            i=0
            flag=0
            l=self.lenHashTable
            while i<=l and l!=0:
                if self.HashTable[(x+i*y)%l]==[-1,-1]:
                    self.HashTable[(x+i*y)%l]=[key,data]
                    self.keys.append([key,data])
                    self.helping[(x+i*y)%l]=0
#                     print('Key added')
                    flag=1
                    break
                else:
                    i=i+1
            if flag==0:
                k=self.lenHashTable+1
                while(1):
                    if sympy.isprime(k):
                        self.lenHashTable=k
                        break
                    else:
                        k=k+1
                self.keys.append([key,data])
                
        #         self.lenHashTable=self.HashTableSize(keys)
                self.helping=[0]*self.lenHashTable
                self.HashTable=[[-1,-1]]*self.lenHashTable
                self.create(self.keys)

            print('Key added and this is the updated hash table',self.HashTable)
    def hashFunction1(self,key):
        x=41
        k=0
        
        for j in range(len(key)):
            k=k+(x**j)*ord(key[j])
        st=bin(k)
        lent=len(st)
        lent=lent/32

        f='0'
        p=0
        if lent>1:
            while lent>1:
                f=bin(int(f,2) + int(st[32*p:32*(p+1)],2))
                p=p+1
                lent=lent-1

            return int(f,2)%17
        else:
            return k%17
        
        
        
    def hashFunction2(self,key):
        x=41
        k=0
        
        for j in range(len(key)):
            k=k+(x**j)*ord(key[j])
        st=bin(k)
        lent=len(st)
        lent=lent/32

        f='0'
        p=0
        if lent>1:
            while lent>1:
                f=bin(int(f,2) + int(st[32*p:32*(p+1)],2))
                p=p+1
                lent=lent-1

            return 8-(int(f,2)%8) 
        else:
            return 8-(k%8) 
        
        
    def create(self,keys):
        l=self.lenHashTable
        for key in self.keys:
            x=self.hashFunction1(key[0])
            y=self.hashFunction2(key[0])
            i=0
            while self.HashTable[(x+y*i)%l]!=key[0]:
                if self.HashTable[(x+y*i)%l]==[-1,-1] and self.helping[(x+y*i)%l]!=1:
                    self.HashTable[(x+y*i)%l]=[key[0],key[1]]
                    break
                else:
                    i=i+1
        return self.HashTable,self.helping
    def delete(self,key):
        l=self.lenHashTable
        x=self.hashFunction1(key)
        y=self.hashFunction2(key)
        i=0
  
#         if self.HashTable[(x+i)%l]==key:
        while(1): # self.HashTable[(x+i)%l]!=key:
            
            
            y=self.hashFunction2(key)
            if self.HashTable[(x+y*i)%l][0]==key:
                self.HashTable[(x+y*i)%l]=[-1,-1]
                self.helping[(x+y*i)%l]=1
                return self.HashTable
            elif i==l:#self.HashTable[(x+i)%l]==-1 and self.helping[(x+i)%l]!=1:
#                     self.HashTable[(x+i)%l]=key
                print('Error Key not found')
                break
           
            i=i+1
    def search(self,key):
        l=self.lenHashTable
        
        
        if l==0:
            return False
        x=self.hashFunction1(key)
        y=self.hashFunction2(key)
        i=0
   
#         if self.HashTable[(x+i)%l]==key:
        while(1): # self.HashTable[(x+i)%l]!=key:
            
    
            
            
            if self.HashTable[(x+y*i)%l][0]==key:
                print('Key is present at index:',(x+i*i)%l)
                self.helping[(x+y*i)%l]=1
                return (x+i*i)%l
            elif i==l:#self.HashTable[(x+i)%l]==-1 and self.helping[(x+i)%l]!=1:
#                     self.HashTable[(x+i)%l]=key
                print('Error Key not found',end=' ')
                return False
        
            i=i+1
#         print(self.HashTable)
    def ValueAtKey(self,key):
        x=self.search(key)
        if x==False:
            pass
        else:
            print('value at key=',key,'is',self.HashTable[x][1])
        


# In[ ]:





# In[76]:


ch=Chaining() #Here object for hashing with separate chaining using AVL is created uncomment following lines to see operations.
# ch.insert(3,'a')
# ch.insert(33,'b')
# ch.insert(333,'c')
# ch.ValueAtKey(333)
# ch.delete(3)
# ch.search(432)


# In[77]:


lp=LinearProb() #Here object for hashing with linear probing is created uncomment following lines to see operations.
# lp.Add('b',2)
# lp.Add('c',3)
# lp.Add('d',4)
# lp.Add('e',5)
# lp.Add('f',6)
# lp.Add('g',7)
# lp.Add('h',8)
# lp.Add('i',9)
# lp.search('b')
# lp.ValueAtKey('b')
# lp.delete('b')


# In[78]:


dp=DoubleHash() #Here object for double hashing  is created uncomment following lines to see operations.
# dp.Add('b',2)
# dp.Add('c',3)
# dp.Add('d',4)
# dp.Add('e',5)
# dp.Add('f',6)
# dp.Add('g',7)
# dp.Add('h',8)
# dp.search('b')
# dp.ValueAtKey('b')
# dp.delete('b')


# In[ ]:





# In[ ]:




